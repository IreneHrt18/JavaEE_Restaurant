create trigger INSERT_USERS_ID_TRI
  before insert
  on USERS_TABLE
  for each row
  begin 
select userid_seq.nextval into :new.userid
from dual;
end;
/

