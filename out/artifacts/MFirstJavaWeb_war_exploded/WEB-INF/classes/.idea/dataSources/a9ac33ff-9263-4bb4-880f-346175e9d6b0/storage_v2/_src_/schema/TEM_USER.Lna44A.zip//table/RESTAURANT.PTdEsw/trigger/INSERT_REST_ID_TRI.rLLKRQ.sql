create trigger INSERT_REST_ID_TRI
  before insert
  on RESTAURANT
  for each row
  begin 
select restaurantid_seq.nextval into :new.restaurantid
from dual;
end;
/

