create trigger INSERT_DISH_ID_TRI
  before insert
  on DISH
  for each row
  begin 
select dishid_seq.nextval into :new.dishid
from dual;
end;
/

