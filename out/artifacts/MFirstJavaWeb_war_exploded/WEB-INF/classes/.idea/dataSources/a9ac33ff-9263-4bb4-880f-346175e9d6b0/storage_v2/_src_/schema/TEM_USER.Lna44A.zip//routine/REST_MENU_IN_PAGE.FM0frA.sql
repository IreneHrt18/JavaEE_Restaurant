create procedure rest_menu_in_page(
restaurant_id in out number,
dish_id in out number,
row_num in number

) is
  begin
    select DISHID,RESTAURANTID
    into dish_id,restaurant_id
      from
                  (select rownum r,menu.* from menu 
                   where RESTAURANTID=restaurant_id or DISHID=dish_id) e
    where r =row_num ;
  end;
/

