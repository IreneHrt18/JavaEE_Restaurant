create procedure  sele_dish(
dish_id in int,
dish_name in varchar
) is
  begin
    select * from DISH
        where DISHID=dish_id or name=dish_name;
  end;
/

