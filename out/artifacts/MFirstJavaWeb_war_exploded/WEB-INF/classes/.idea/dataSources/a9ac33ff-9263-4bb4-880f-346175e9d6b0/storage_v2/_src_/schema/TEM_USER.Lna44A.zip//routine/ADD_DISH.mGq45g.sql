create procedure  add_dish(
dish_id in int,
name in varchar,
price in int,
img in varchar,
des in varchar
) is
  begin
    insert into DISH
        values (dish_id,name,price,img,des);
  end;
/

